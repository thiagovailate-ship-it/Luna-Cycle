# Luna Cycle — entrega do web app

O aplicativo está pronto e rodando em **preview ao vivo** na porta `5173`. Os arquivos ZIP foram atualizados com a versão 2.0.0.

## Novo foco

O Luna Cycle agora é um web app **100% dedicado ao ciclo menstrual**. As jornadas de gravidez, menopausa e exames/preventivo foram removidas da interface, navegação e rotas ativas. Os arquivos dessas telas foram preservados no código para uma possível reativação futura — os caminhos antigos redirecionam para o início.

## Como acessar

1. Abra a visualização ao vivo do workspace.
2. Use a conta de demonstração ou crie uma nova conta local.

**Conta demo**

- E-mail: `demo@lunacycle.app`
- Senha: `luna123`

## Arquivos principais

- `luna-cycle/` — projeto React/Vite completo.
- `luna-cycle-complete.zip` — código-fonte + build de produção.
- `luna-cycle-static-build.zip` — somente os arquivos estáticos prontos para hospedagem.
- `luna-cycle/README.md` — documentação técnica e funcionalidades.
- `luna-cycle-review/` — capturas de tela das principais telas em desktop e mobile.

## O que foi entregue na versão 2.0.0

### Foco no período menstrual
- Dashboard com dia do ciclo, fase atual, previsão da próxima menstruação e ovulação.
- Calendário do ciclo com menstruação, previsão, fase fértil, ovulação e lembretes.
- Registro da menstruação com data, duração, fluxo e observações.
- **Fluxo dia a dia** com níveis leve, moderado e intenso, além de opção de desfazer.
- Sintomas e humor com linguagem de ícones própria e opções focadas no ciclo.
- Histórico, previsões, relatórios, saúde hormonal, bem-estar, dicas e dispositivos.
- Lembretes com categorias de ciclo, sintomas, medicação e bem-estar.

### Visual e ícones
- Redesign moderno mantendo a identidade rosé/blush.
- Nova biblioteca de ícones SVG duotone usada em navegação, cards, ações rápidas e calendário.
- Rostos de humor ilustrados em SVG no lugar de emojis.
- Arte de ciclo orbital no dashboard, sidebar e telas de boas-vindas.
- Cards maiores, gradiente no hero, mais contraste, sombras suaves e microinterações.
- Sidebar com cartão de progresso do ciclo e bottom nav com visual de app.
- Favicon, manifest, título e descrição atualizados.

### Praticidade, privacidade e acessibilidade
- Registro rápido com tecla `Q` e botão flutuante.
- Início da menstruação em um toque com opção de desfazer.
- Respiração guiada de 1 minuto.
- Modo discreto, PIN, bloqueio rápido e bloqueio automático.
- Texto maior, alto contraste, redução de movimento, foco visível e alvos de toque ampliados.
- Busca global com `Ctrl/Cmd + K` e navegação por teclado.
- Dados locais, backup/importação e exportação CSV.

## Comandos

```bash
cd luna-cycle
npm install
npm run dev
```

Para gerar a versão de produção:

```bash
npm run build
npm run preview
```

## Validação

- `npm run build` — concluído sem erros nem aviso de tamanho de chunk. Bundle final: `420.83 kB` JS / `121.63 kB` gzip e `87.80 kB` CSS / `16.49 kB` gzip.
- `npm run lint` — concluído sem erros nem avisos.
- QA de navegação, rotas ativas e redirecionamento das rotas antigas.
- QA de interações: login, registro rápido, humor, água, fluxo dia a dia, menstruação, sintomas, lembretes, relatórios e persistência.
- QA de privacidade: modo discreto, PIN, bloqueio/desbloqueio e notificações neutras.
- QA de acessibilidade: zoom, alto contraste, movimento reduzido e foco por teclado.
- QA responsivo em desktop e mobile 390px, com overflow zero.

> Observação: a opção escolhida continua sendo front-end completo com dados locais. O PIN é uma barreira visual/local e não criptografa o banco do navegador. Para sincronização entre dispositivos, o próximo passo é adicionar API e banco de dados.
